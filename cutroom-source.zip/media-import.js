const MediaImport = {
  type(file) {
    if (/^video\//i.test(file.type)) return 'video';
    if (/^image\//i.test(file.type)) return 'image';
    const extension = file.name.split('.').pop().toLowerCase();
    if (['mp4', 'm4v', 'mov', 'webm', 'mkv', 'avi', 'mpeg', 'mpg', '3gp', 'mts', 'm2ts', 'ts', 'wmv', 'ogv'].includes(extension)) return 'video';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'svg', 'heic', 'heif'].includes(extension)) return 'image';
    throw new Error('File type not recognized. Choose a video or image file.');
  },
  probe(src, type, timeoutMs = 20000) {
    return new Promise((resolve, reject) => {
      const element = document.createElement(type === 'video' ? 'video' : 'img');
      const timer = setTimeout(() => finish(new Error('Reading timed out. Try a shorter video or convert it to MP4 with H.264 video.')), timeoutMs);
      const finish = (error, duration = 5) => {
        clearTimeout(timer);
        element.onload = element.onloadeddata = element.onerror = null;
        if (type === 'video') { element.removeAttribute('src'); element.load(); }
        error ? reject(error) : resolve(duration);
      };
      element.onerror = () => finish(new Error(type === 'video'
        ? 'This browser cannot decode this video. Convert it to MP4 with H.264 video, then import it again.'
        : 'This browser cannot open this image. Try PNG or JPEG.'));
      if (type === 'video') {
        element.preload = 'auto';
        element.muted = true;
        element.playsInline = true;
        element.onloadeddata = () => {
          if (!Number.isFinite(element.duration) || element.duration <= 0 || !element.videoWidth)
            finish(new Error('No playable video track was found in this file.'));
          else finish(null, element.duration);
        };
      } else element.onload = () => finish(null);
      element.src = src;
    });
  }
};
